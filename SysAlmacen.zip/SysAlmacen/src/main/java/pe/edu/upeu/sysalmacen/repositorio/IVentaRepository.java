package pe.edu.upeu.sysalmacen.repositorio;

import pe.edu.upeu.sysalmacen.modelo.Venta;

public interface IVentaRepository extends ICrudGenericoRepository<Venta, Long>{

}
