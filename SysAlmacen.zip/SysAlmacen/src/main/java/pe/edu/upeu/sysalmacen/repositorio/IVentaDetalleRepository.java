package pe.edu.upeu.sysalmacen.repositorio;

import pe.edu.upeu.sysalmacen.modelo.VentaDetalle;

public interface IVentaDetalleRepository extends ICrudGenericoRepository<VentaDetalle, Long>{
}
