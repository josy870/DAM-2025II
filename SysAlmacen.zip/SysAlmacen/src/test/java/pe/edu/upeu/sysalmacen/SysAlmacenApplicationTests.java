package pe.edu.upeu.sysalmacen;

/*import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysAlmacenApplicationTests {

	@Test
	void contextLoads() {
	}

}*/
